#include <stdint.h>
#include <stdlib.h>
#include <avr/pgmspace.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include <string.h>

#include "sequence.h"
#include "uart.h"
#include "utils.h"
#include "initialize.h"
#include "interupts.h"


volatile uint8_t leftSeg;
volatile uint8_t rightSeg;

volatile uint8_t sequenceSelected = 0;
volatile uint8_t sequenceStep = 0;

uint32_t offset = 0;

volatile uint8_t nextDuration;
volatile uint8_t currentDurationLeft;
volatile uint8_t nextBrightness;
volatile uint8_t nextOctave;
volatile uint8_t nextNote;

uint32_t freq;

uint32_t noteFreq[12] = {
        901120,
        954703,
        1011473,
        1071618,
        1135340,
        1202851,
        1274376,
        1350154,
        1430439,
        1515497,
        1605613,
        1701088,

};

uint8_t numToMask[16] = {
        0b00001000,
        0b01101011,
        0b01000100,
        0b01000001,
        0b00100011,
        0b00010001,
        0b00110000,
        0b01001011,
        0b00000000,
        0b00000011,
        0b00000010,
        0b00110000,
        0b00011100,
        0b01100000,
        0b00010100,
        0b00010110
};

void setSegSequence(void){
    leftSeg = numToMask[(sequenceSelected & 0xF)];
    rightSeg = numToMask[(sequenceSelected >> 4)];
}

void getNextStep(void);
void setNextStep(void);


typedef enum {
    NONE,
    SLASH,
    D_SLASH,
    CMD_SEQ,
    CMD_TEST,
    CMD_EXIT,
    CMD_PAUSE,
    CMD_STEP,
    CMD_SYNC,
    CMD_SEQIDX,
    CMD_TEST_SEQ,
    CMD_TEST_SEQNS,
} cmdModes;

typedef enum {
    START,
    SEQUENCING,
    NEXT,
    STOP,
    STOPPED,
} sequenceStatus;

extern volatile sequenceStatus sequenceState = STOPPED;


int main(void) {
//    SYSTEM CLOCK SETUP
    CCP = CCP_IOREG_gc;
    CLKCTRL.MCLKCTRLB  = 0x1;


//    Init


    spi_init();
    uart_init();
    button_init();
    tcb0_init();
    adc_init();
    tca0_init();
//    tcb1_init();

    uint8_t pb = 0;
    uint8_t pb_prev = 0;
    uint8_t pb_changed;
    uint8_t pb_falling;





//    BRIGHTNESS CALCULATION
//    TCA0_SINGLE_CMP1 = 29733UL - ((29733UL * (0xFF + 1)) >> 8);



    cmdModes cmdMode = NONE;

    uint8_t input;

    while (1) {
        if (USART0.STATUS & USART_RXCIF_bm) {
            input = USART0.RXDATAL;
        }

        switch (cmdMode) {
            case NONE:
                if (input == '/') cmdMode = SLASH;
                break;
            case SLASH:
                if (input == '/') cmdMode = D_SLASH;
                else cmdMode = NONE;
                break;
            case D_SLASH:
                if(input == 's') cmdMode = CMD_SEQ;
                else if(input == 't') cmdMode = CMD_TEST;
                else if(input == 'e') cmdMode = CMD_EXIT;
                else if(input == 'p') cmdMode = CMD_PAUSE;
                else if(input == 'n') cmdMode = CMD_STEP;
                else if(input == 'y') cmdMode = CMD_SYNC;
                else if(input == 'i') cmdMode = CMD_SEQIDX;
                else if(input == 'd') cmdMode = CMD_TEST_SEQ;
                else if(input == 'u') cmdMode = CMD_TEST_SEQNS;
                else if(input == '/') cmdMode = D_SLASH;
                else {
                    cmdMode = NONE;
                    uart_puts("#NACK\n");
                }
                break;
            case CMD_SEQIDX:
// GET SET APPROPRIATE VALUES
                sequenceState = START;

                cmdMode = NONE;
                break;
            default:
                cmdMode = NONE;
                break;

        }

//        Buttons
        pb_prev = pb;
        pb = pb_state;

        pb_changed = pb ^ pb_prev;
        pb_falling = pb_changed & ~pb;

        if(pb_falling & PIN6_bm && sequenceSelected < 0xFF){
            if(sequenceState == STOPPED) {
                sequenceSelected += 1;
            } else {
                uart_putc('L');
                sequenceState = NEXT;
            }
        } else if(pb_falling & PIN5_bm && sequenceSelected > 0) {
            sequenceSelected -= 1;
        } else if(pb_falling & PIN7_bm) {
            sequenceState = START;
        } else if (!(PORTA.IN & PIN4_bm)) {
            sequenceSelected = ADC0.RESULT;
        }

        switch (sequenceState) {
            case START:
//                SET OFFSET
                offset = 32 * sequenceSelected;

//                SET DESCRAMBLE STATE
                for (uint32_t i = 0; i < offset; ++i) {
                    next();
                }

                getNextStep();
                setNextStep();

                PORTB.DIRSET = PIN1_bm;
                PORTB.DIRSET = PIN0_bm;

                sequenceState = NEXT;
                break;

            case NEXT:
                getNextStep();

                sequenceState = SEQUENCING;

                break;

            default:
                break;

        }



    }

}

void setNextStep(void) {
    freq = noteFreq[nextNote] >> (15 - nextOctave);
    TCA0.SINGLE.PER = freq;
    TCA0.SINGLE.CMP0BUF = (freq >> 1);
    TCA0.SINGLE.CMP1BUF = freq - ((freq * (nextBrightness + 1)) >> 8);
}



void getNextStep(void) {
    char a = pgm_read_byte_near(SEQUENCE + offset);
    char b = pgm_read_byte_near(SEQUENCE + offset + 1);
    char c = pgm_read_byte_near(SEQUENCE + offset + 2);
    char d = pgm_read_byte_near(SEQUENCE + offset + 3);

    offset = offset + 4;

    uint32_t data = decode(a,b,c,d);



    nextDuration = data >> 16;
    nextBrightness = data >> 8;
    uint8_t feqData = data;

    descramble(&nextDuration);
    descramble(&nextBrightness);
    descramble(&feqData);


    nextOctave = feqData >> 4;
    nextNote = feqData & 0b00001111;
}








//    uint8_t B64_RESULT[12282];
//    for (uint16_t k = 0; k < strlen(TEST_BASE64); k++) {
//        char a = pgm_read_byte_near(TEST_BASE64 + (k*4));
//        char b = pgm_read_byte_near(TEST_BASE64 + (k*4) + 1);
//        char c = pgm_read_byte_near(TEST_BASE64 + (k*4) + 2);
//        char d = pgm_read_byte_near(TEST_BASE64 + (k*4) + 3);
//
//        uint32_t hex3 = decode(a, b, c, d);
//
//        uint8_t B64byte1 = hex3 >> 16;
//        uint8_t B64byte2 = hex3 >> 8;
//        uint8_t B64byte3 = hex3;
//
//        B64_RESULT[(k*3)] = B64byte1;
//        B64_RESULT[(k*3) + 1] = B64byte2;
//        B64_RESULT[(k*3) + 2] = B64byte3;
//    }
//
//    printf("Start2\n");
//    for (uint16_t i = 0; i < 10; i++) test(&B64_RESULT[i]);

