extern volatile uint8_t leftSeg;
extern volatile uint8_t rightSeg;
extern volatile uint8_t sequenceSelected;
extern volatile uint8_t sequenceStep;
extern volatile uint8_t nextDuration;
extern volatile uint8_t currentDurationLeft;


extern volatile uint8_t sequenceState;

void setSegSequence(void);
void setNextStep(void);