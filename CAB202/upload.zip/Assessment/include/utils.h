void next(void);
void descramble(uint8_t* a);
uint32_t decode(const char a, const char b, const char c, const char d);
static const unsigned char base64_table[65];
uint8_t hexToAscii(uint8_t i);