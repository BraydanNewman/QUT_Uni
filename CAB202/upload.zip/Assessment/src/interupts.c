#include <stdint.h>
#include <stdlib.h>
#include <avr/pgmspace.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include <string.h>

#include "main.h"
#include "uart.h"

volatile uint8_t pb_state = 0xFF;


void spi_write(uint8_t b){
    SPI0.DATA = b;
}

void displaySegments(void){
    static uint8_t digit = 0;
    if(digit) {
        spi_write(leftSeg);
    } else {
        spi_write((rightSeg)|10000000);
    }
    digit = !digit;
}


ISR(SPI0_INT_vect){
        PORTA.OUTCLR = PIN1_bm;
        PORTA.OUTSET = PIN1_bm;
        SPI0.INTFLAGS = SPI_IE_bm;
}


ISR(TCB0_INT_vect) {
    if(currentDurationLeft > 0) {
        currentDurationLeft--;
    } else {
        setNextStep();


    }

//    Buttons Debounce
    static uint8_t count0 = 0;
    static uint8_t count1 = 1;
    uint8_t pb_sample = PORTA.IN;
    uint8_t pb_changed = pb_sample ^ pb_state;
    count1 = (count1 ^ count0) & pb_changed;
    count0 = ~count0 & pb_changed;
    pb_state ^= (count1 & count0) | (pb_changed & pb_state);

    setSegSequence();
    displaySegments();

    TCB0.INTFLAGS = TCB_CAPT_bm; //  Acknowledge Interrupt
}
