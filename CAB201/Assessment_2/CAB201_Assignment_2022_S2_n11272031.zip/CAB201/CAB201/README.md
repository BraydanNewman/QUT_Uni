# CAB201 Auction House

### Version 0.0.10

--------------------
Current version compatible up to user story 10.

User Story 1: True

User Story 2: True

User Story 3: True

User Story 4: True

User Story 5: True

User Story 6: True

User Story 7: True

User Story 8: True

User Story 9: True

User Story 10: True

User Story 11: Partially

User Story 12: False

User Story 13: False

User Story 14: False

User Story 15: False

-----------------------

Run the following command in this directory to execute program:

```shell
dotnet run
```

Tested on dotnet version: `6.0.110`