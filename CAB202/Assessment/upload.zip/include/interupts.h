volatile uint8_t pb_state;
void spi_write(uint8_t b);