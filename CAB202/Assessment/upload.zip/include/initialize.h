#include <avr/io.h>
#include <avr/interrupt.h>

void tca0_init(void);
void tcb0_init(void);
void tcb1_init(void);
void spi_init(void);
void button_init(void);
void adc_init(void);
