import React from "react";

function Footer() {
  return (
    <div className="footer">
      <label className="m-4">WATER BOTTLES</label>
      <label className="m-4">MORE RANDOM @#$%@ :)</label>
      <label className="m-4">IDK</label>
      <label className="m-4">WHAT</label>
      <label className="m-4">IM</label>
      <label className="m-4">SAYING</label>
      <label className="m-4">NON OF THESE WORK LOL</label>
    </div>
  );
}

export default Footer;
