#include <stdint.h>
void spi_init(void);       
void spi_write(uint8_t b);
